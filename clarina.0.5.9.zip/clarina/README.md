=== Clarina ===
Contributors:		madalinm
Tags:				one-column, two-columns, right-sidebar, custom-header, custom-background, custom-colors, custom-menu, featured-images, full-width-template, rtl-language-support, sticky-post, threaded-comments, translation-ready, e-commerce, blog, portfolio
Requires at least:	3.3.0
Tested up to:		4.7.2

== Description ==
Clarina is a free and beautiful one page WordPress theme build for Travel Blogs, Agencies and Hotels

= License =
Clarina is an WordPress theme licensed under the GPL3. Clarina is a child theme of Llorix One Lite

# Images

    License: CC0 Public Domain, Free for commercial use, No attribution required

    Screenshot images:
        https://pixabay.com/en/new-york-city-brooklyn-bridge-night-336475/

    File: \images\background-images\parallax-img\team-img.jpg
    Source: https://pixabay.com/en/mountains-fog-mist-clouds-sunset-984101/

    File: \images\background-images\background.jpg
    Source: https://pixabay.com/en/new-york-city-brooklyn-bridge-night-336475/

    File: \images\background-images\
    Source: https://pixabay.com/en/new-york-city-brooklyn-bridge-night-336475/

    File: /images/about-us.png
    Source: https://pixabay.com/en/business-professional-teamwork-1219868/

    File: /images/background-blog.jpg
    Source: https://pixabay.com/en/texting-mobile-phones-hands-two-1490691/

    File: /images/phone.png
    Source: https://pixabay.com/en/cinque-terre-italy-rocks-sea-water-279013/