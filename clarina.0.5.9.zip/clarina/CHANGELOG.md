
### 0.5.9 - 29/03/2017
**Changes:** 
- Fixed double enqueuing of theme style file
- Fixed sanitization issues
- Replaced custom functions with core ones
- Fixed travis

### 0.5.6 - 12/03/2017
**Changes:** 
- Added sane defaults
- Removed upsells from parent theme

### 0.5.5 - 13/02/2017
**Changes:** 
- Updated theme license
- Changed footer copyright

### 0.5.4 - 11/01/2017
**Changes:** 
- Fixed issue with Ribbon subtitle sanitize function
- Fixed issue with parent pages not visible in footer menu

### 0.5.3 - 28/11/2016
**Changes:** 
- Update style.css

### 0.5.2 - 28/11/2016
**Changes:** 
- Added grunt
- Fixed small layout issues
- Reorganize files to use hooks and filters
- Added license for all images

### 0.4 - 02/11/2016
**Changes:** 
- Development

### 0.3 - 02/11/2016
**Changes:** 
- Update style.css

### 0.2 - 01/11/2016
**Changes:** 
- Improved layout

